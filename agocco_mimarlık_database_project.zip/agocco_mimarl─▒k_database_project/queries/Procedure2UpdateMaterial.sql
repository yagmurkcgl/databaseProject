--STORED PROC 2 
	CREATE PROCEDURE sp_UpdateMaterial
	(
		@materialID nvarchar(11),
		@materialName nvarchar(255),
		@materialCount int,
		@materialPrice int
	)
	as
	begin
		UPDATE MATERIAL
		SET materialName=@materialName,materialCount=@materialCount,materialPrice=@materialPrice
		WHERE materialID=@materialID
	end

	exec sp_UpdateMaterial '0026', 'Deneme', 500, 1500
