	--STORED PROCEDURE 5
	CREATE PROCEDURE UpdateEmployeePhoneNumber
	(
	  @IdentityNumber nvarchar(11),
	  @PhoneNumber varchar(11)
	)
	AS
	BEGIN
	  UPDATE EMPLOYEE
	  SET phoneNumber = @PhoneNumber
	  WHERE identityNumber = @IdentityNumber
	END

	EXEC UpdateEmployeePhoneNumber '12456953264', '05522084521'
