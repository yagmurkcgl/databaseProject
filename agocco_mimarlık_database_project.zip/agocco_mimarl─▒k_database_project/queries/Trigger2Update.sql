--UPDATE TRIGGER

CREATE TRIGGER UPDATEMATERIALTRIGGER
 ON MATERIAL
 AFTER UPDATE
 AS
 BEGIN
	UPDATE STORAGE
	SET materialName = (SELECT materialName FROM MATERIAL WHERE materialID = (SELECT materialID FROM inserted)),
		materialCount = (SELECT materialCount FROM MATERIAL WHERE materialID = (SELECT materialID FROM inserted))
	WHERE materialID = (SELECT materialID FROM inserted)
END