--VIEW4
	CREATE VIEW CalculateSalary_VIEW4 AS
	SELECT e.rank, COUNT(rank) NumberOfRank, AVG(salary) AvarageSalary , SUM(salary) SumSalary
	FROM EMPLOYEE E
	Group by e.rank

	SELECT *
	FROM CalculateSalary_VIEW4
	