--VIEW 1
	CREATE VIEW EMPLOYEE_VIEW1 AS 
	SELECT e.FullName, e.age, e.rank
	FROM EMPLOYEE E
	INNER JOIN COMPANY C on e.companyTaxNo=c.companyTaxNo
	WHERE e.age>=25 and e.rank='Driver'
	
	SELECT * 
	FROM EMPLOYEE_VIEW1