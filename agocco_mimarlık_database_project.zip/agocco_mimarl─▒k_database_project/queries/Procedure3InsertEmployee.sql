--STORED PROCEDURE 3
	CREATE PROCEDURE sp_InsertEmployee
	(
		@identityNumber nvarchar(11), 
		@firstName varchar(25), 
		@lastName varchar(35), 
		@phoneNumber varchar(11),
		@e_mailAddress nvarchar(50), 
		@address nvarchar(50),
		@rank varchar(50), 
		@salary int, 		
		@age int
	)
	as
	begin
		INSERT INTO EMPLOYEE(identityNumber,firstName,lastName,phoneNumber,
		e_mailAddress,address,rank,salary,age) 
		VALUES(@identityNumber,@firstName,@lastName,@phoneNumber,
		      @e_mailAddress,@address,@rank,@salary,@age)
	end

	exec sp_InsertEmployee '14145678954', 'Mert Efe', 'Karak�se', '05523090847', 'mertkarakose@gmail.com','�stanbul/T�rkiye','SQLDeveloper',50000,22
