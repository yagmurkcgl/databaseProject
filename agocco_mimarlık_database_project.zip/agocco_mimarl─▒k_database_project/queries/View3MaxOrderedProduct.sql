--VIEW 3	
	CREATE VIEW MaxOrderedProduct_VIEW3 AS
	SELECT p.productID,p.productName, p.productPrice, o.postalCode, COUNT(*) MaxOrderedProduct
	FROM PRODUCT p
	INNER JOIN OrderedProduct OP on p.productID=op.productID
	INNER JOIN ORDERS O on o.orderID=op.orderID
	INNER JOIN CITY C on c.postalCode=o.postalCode
	Group by p.productID,p.productName,p.productPrice,o.postalCode
	Having COUNT(*)=MAX(p.productID)

	SELECT * 
	FROM MaxOrderedProduct_VIEW3
	ORDER BY postalCode asc
	
	