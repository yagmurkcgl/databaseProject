--STORED PROC 1 
	CREATE PROCEDURE sp_OrderKitchenProcedure1
	(
		@orderName varchar(255)
	)
	as
	begin
		Select orderID,orderDate,o.orderName
		From ORDERS o 
		Where orderName=@orderName
	end

	exec sp_OrderKitchenProcedure1 @orderName='Sofa set'
	