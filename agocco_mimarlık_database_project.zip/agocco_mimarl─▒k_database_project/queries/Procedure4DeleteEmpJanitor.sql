--STORED PROCEDURE 4
	CREATE PROCEDURE sp_DeletetotalEmployeeJanitorProc4
	(
		@rank varchar(50)
	)
	as

	begin
		DELETE FROM EMPLOYEE
		WHERE RANK=@rank
	end


	exec sp_DeletetotalEmployeeJanitorProc4 Janitor
