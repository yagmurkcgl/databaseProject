--STORED PROCEDURE 6
		CREATE PROCEDURE InsertInvoice
	(
	  @InvoiceNumber varchar(25),
	  @TotalOrderPrice int,
	  @InvoiceDate date,
	  @ProductPrice nvarchar(55)
	)
	AS
	BEGIN
	  INSERT INTO INVOICE
	  (invoiceNumber, totalOrderPrice, invoiceDate, productPrice)
	  VALUES
	  (@InvoiceNumber, @TotalOrderPrice, @InvoiceDate, @ProductPrice)
	END

	EXEC InsertInvoice 'GIB202200026', 4500, '2022-01-06', '1000+3500'
