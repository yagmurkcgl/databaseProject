--VIEW 2
	CREATE VIEW CUSTOMER_VIEW2 AS
	SELECT c.identityNumber,c.FullNAme, c.address, c.phoneNumber 
	FROM CUSTOMER C
	WHERE c.address NOT LIKE '%T�rkiye%'
	
	SELECT *
	FROM CUSTOMER_VIEW2 
	ORDER BY identityNumber desc 
	