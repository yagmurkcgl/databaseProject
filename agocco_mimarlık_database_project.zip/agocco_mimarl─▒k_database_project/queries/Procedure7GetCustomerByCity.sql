	--STORED PROCEDURE 7
		
		CREATE PROCEDURE GetCustomersByCity
	(
	  @CityName varchar(255)
	)
	AS
	BEGIN
	  SELECT * FROM CUSTOMER c
	  INNER JOIN CITY ct ON c.address = ct.cityName
	  WHERE ct.cityName = @CityName
	END

	EXEC GetCustomersByCity '�stanbul/T�rkiye'
